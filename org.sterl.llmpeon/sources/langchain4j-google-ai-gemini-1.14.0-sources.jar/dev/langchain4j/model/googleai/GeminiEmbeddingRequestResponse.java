package dev.langchain4j.model.googleai;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import dev.langchain4j.model.googleai.GeminiEmbeddingRequestResponse.GeminiEmbeddingResponse.GeminiEmbeddingResponseValues;
import java.util.List;

public final class GeminiEmbeddingRequestResponse {
    private GeminiEmbeddingRequestResponse() {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    record GeminiEmbeddingRequest(
            @JsonProperty("model") String model,
            @JsonProperty("content") GeminiContent content,
            @JsonProperty("taskType") GoogleAiEmbeddingModel.TaskType taskType,
            @JsonProperty("title") String title,
            @JsonProperty("outputDimensionality") Integer outputDimensionality) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record GeminiEmbeddingResponse(
            @JsonProperty("embedding") GeminiEmbeddingResponseValues embedding) {
        @JsonIgnoreProperties(ignoreUnknown = true)
        public record GeminiEmbeddingResponseValues(
                @JsonProperty("values") List<Float> values) {}
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    record GeminiBatchEmbeddingRequest(
            @JsonProperty("requests") List<GeminiEmbeddingRequest> requests) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    record GeminiBatchEmbeddingResponse(
            @JsonProperty("embeddings") List<GeminiEmbeddingResponseValues> embeddings) {}
}
