package dev.langchain4j.model.openai;

import static com.fasterxml.jackson.databind.SerializationFeature.INDENT_OUTPUT;
import static dev.langchain4j.http.client.sse.ServerSentEventParsingHandleUtils.toStreamingHandle;
import static dev.langchain4j.internal.InternalStreamingChatResponseHandlerUtils.withLoggingExceptions;
import static dev.langchain4j.internal.JsonSchemaElementUtils.toMap;
import static dev.langchain4j.internal.Utils.getOrDefault;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import dev.langchain4j.agent.tool.ToolExecutionRequest;
import dev.langchain4j.agent.tool.ToolSpecification;
import dev.langchain4j.data.image.Image;
import dev.langchain4j.data.message.AiMessage;
import dev.langchain4j.data.message.ChatMessage;
import dev.langchain4j.data.message.Content;
import dev.langchain4j.data.message.ImageContent;
import dev.langchain4j.data.message.PdfFileContent;
import dev.langchain4j.data.message.SystemMessage;
import dev.langchain4j.data.message.TextContent;
import dev.langchain4j.data.message.ToolExecutionResultMessage;
import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.exception.UnsupportedFeatureException;
import dev.langchain4j.http.client.HttpClient;
import dev.langchain4j.http.client.HttpClientBuilder;
import dev.langchain4j.http.client.HttpClientBuilderLoader;
import dev.langchain4j.http.client.HttpMethod;
import dev.langchain4j.http.client.HttpRequest;
import dev.langchain4j.http.client.SuccessfulHttpResponse;
import dev.langchain4j.http.client.log.LoggingHttpClient;
import dev.langchain4j.http.client.sse.CancellationUnsupportedHandle;
import dev.langchain4j.http.client.sse.DefaultServerSentEventParser;
import dev.langchain4j.http.client.sse.ServerSentEvent;
import dev.langchain4j.http.client.sse.ServerSentEventContext;
import dev.langchain4j.http.client.sse.ServerSentEventListener;
import dev.langchain4j.internal.ExceptionMapper;
import dev.langchain4j.internal.InternalStreamingChatResponseHandlerUtils;
import dev.langchain4j.model.chat.request.ChatRequest;
import dev.langchain4j.model.chat.request.ResponseFormat;
import dev.langchain4j.model.chat.request.ResponseFormatType;
import dev.langchain4j.model.chat.request.ToolChoice;
import dev.langchain4j.model.chat.request.json.JsonObjectSchema;
import dev.langchain4j.model.chat.request.json.JsonRawSchema;
import dev.langchain4j.model.chat.request.json.JsonSchema;
import dev.langchain4j.model.chat.response.ChatResponse;
import dev.langchain4j.model.chat.response.CompleteToolCall;
import dev.langchain4j.model.chat.response.PartialToolCall;
import dev.langchain4j.model.chat.response.StreamingChatResponseHandler;
import dev.langchain4j.model.chat.response.StreamingHandle;
import dev.langchain4j.model.output.FinishReason;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

class OpenAiResponsesClient {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper()
            .enable(INDENT_OUTPUT);

    private static final String DEFAULT_BASE_URL = "https://api.openai.com/v1";
    private static final String OPENAI_ORGANIZATION_HEADER = "OpenAI-Organization";
    private static final String STREAM_DONE_MARKER = "[DONE]";

    private static final String EVENT_OUTPUT_TEXT_DELTA = "response.output_text.delta";
    private static final String EVENT_OUTPUT_ITEM_ADDED = "response.output_item.added";
    private static final String EVENT_FUNCTION_CALL_ARGUMENTS_DELTA = "response.function_call_arguments.delta";
    private static final String EVENT_FUNCTION_CALL_ARGUMENTS_DONE = "response.function_call_arguments.done";
    private static final String EVENT_OUTPUT_ITEM_DONE = "response.output_item.done";
    private static final String EVENT_REASONING_TEXT_DELTA = "response.reasoning_text.delta";
    private static final String EVENT_REASONING_SUMMARY_TEXT_DELTA = "response.reasoning_summary_text.delta";
    private static final String EVENT_RESPONSE_COMPLETED = "response.completed";
    private static final String EVENT_RESPONSE_INCOMPLETE = "response.incomplete";
    private static final String EVENT_RESPONSE_FAILED = "response.failed";
    private static final String EVENT_RESPONSE_ERROR = "response.error";

    private static final String FIELD_TYPE = "type";
    private static final String FIELD_ROLE = "role";
    private static final String FIELD_CONTENT = "content";
    private static final String FIELD_NAME = "name";
    private static final String FIELD_DESCRIPTION = "description";
    private static final String FIELD_PARAMETERS = "parameters";
    private static final String FIELD_PROPERTIES = "properties";
    private static final String FIELD_ARGUMENTS = "arguments";
    private static final String FIELD_DELTA = "delta";
    private static final String FIELD_TEXT = "text";
    private static final String FIELD_IMAGE_URL = "image_url";
    private static final String FIELD_FILE_URL = "file_url";
    private static final String FIELD_FILE_DATA = "file_data";
    private static final String FIELD_FILENAME = "filename";
    private static final String FIELD_DETAIL = "detail";
    private static final String FIELD_ITEM = "item";
    private static final String FIELD_ID = "id";
    private static final String FIELD_CALL_ID = "call_id";
    private static final String FIELD_ITEM_ID = "item_id";
    private static final String FIELD_OUTPUT_INDEX = "output_index";
    private static final String FIELD_RESPONSE = "response";
    private static final String FIELD_ERROR = "error";
    private static final String FIELD_MESSAGE = "message";
    private static final String FIELD_OUTPUT = "output";
    private static final String FIELD_USAGE = "usage";
    private static final String FIELD_INPUT_TOKENS = "input_tokens";
    private static final String FIELD_OUTPUT_TOKENS = "output_tokens";
    private static final String FIELD_TOTAL_TOKENS = "total_tokens";
    private static final String FIELD_INPUT_TOKENS_DETAILS = "input_tokens_details";
    private static final String FIELD_CACHED_TOKENS = "cached_tokens";
    private static final String FIELD_OUTPUT_TOKENS_DETAILS = "output_tokens_details";
    private static final String FIELD_REASONING_TOKENS = "reasoning_tokens";
    private static final String FIELD_MODEL = "model";
    private static final String FIELD_INPUT = "input";
    private static final String FIELD_STREAM = "stream";
    private static final String FIELD_STORE = "store";
    private static final String FIELD_TEMPERATURE = "temperature";
    private static final String FIELD_TOP_P = "top_p";
    private static final String FIELD_MAX_OUTPUT_TOKENS = "max_output_tokens";
    private static final String FIELD_MAX_TOOL_CALLS = "max_tool_calls";
    private static final String FIELD_PARALLEL_TOOL_CALLS = "parallel_tool_calls";
    private static final String FIELD_PREVIOUS_RESPONSE_ID = "previous_response_id";
    private static final String FIELD_TOP_LOGPROBS = "top_logprobs";
    private static final String FIELD_TOOLS = "tools";
    private static final String FIELD_TOOL_CHOICE = "tool_choice";
    private static final String FIELD_TRUNCATION = "truncation";
    private static final String FIELD_INCLUDE = "include";
    private static final String FIELD_SERVICE_TIER = "service_tier";
    private static final String FIELD_SAFETY_IDENTIFIER = "safety_identifier";
    private static final String FIELD_PROMPT_CACHE_KEY = "prompt_cache_key";
    private static final String FIELD_PROMPT_CACHE_RETENTION = "prompt_cache_retention";
    private static final String FIELD_REASONING = "reasoning";
    private static final String FIELD_EFFORT = "effort";
    private static final String FIELD_SUMMARY = "summary";
    private static final String FIELD_SUMMARY_TEXT = "summary_text";
    private static final String FIELD_ENCRYPTED_CONTENT = "encrypted_content";
    private static final String FIELD_STRICT = "strict";
    private static final String FIELD_STREAM_OPTIONS = "stream_options";
    private static final String FIELD_INCLUDE_OBFUSCATION = "include_obfuscation";
    private static final String FIELD_TEXT_VERBOSITY = "verbosity";
    private static final String FIELD_FORMAT = "format";
    private static final String FIELD_SCHEMA = "schema";
    private static final String FIELD_ADDITIONAL_PROPERTIES = "additionalProperties";
    private static final String FIELD_STATUS = "status";
    private static final String FIELD_CREATED_AT = "created_at";
    private static final String FIELD_COMPLETED_AT = "completed_at";
    private static final String DEFAULT_IMAGE_MIME_TYPE = "image/jpeg";
    private static final String DEFAULT_PDF_FILENAME = "pdf_file";

    private static final String ROLE_SYSTEM = "system";
    private static final String ROLE_USER = "user";
    private static final String ROLE_ASSISTANT = "assistant";

    static final String ENCRYPTED_REASONING_KEY = "encrypted_reasoning"; // do not change, will break backward compatibility!

    private static final String TYPE_FUNCTION = "function";
    private static final String TYPE_FUNCTION_CALL = "function_call";
    private static final String TYPE_MESSAGE = "message";
    private static final String TYPE_REASONING = "reasoning";
    private static final String TYPE_OUTPUT_TEXT = "output_text";
    private static final String TYPE_OBJECT = "object";
    private static final String TYPE_INPUT_TEXT = "input_text";
    private static final String TYPE_INPUT_IMAGE = "input_image";
    private static final String TYPE_INPUT_FILE = "input_file";
    private static final String TYPE_FUNCTION_CALL_OUTPUT = "function_call_output";
    private static final String TYPE_JSON_OBJECT = "json_object";
    private static final String TYPE_JSON_SCHEMA = "json_schema";

    private final HttpClient httpClient;
    private final String baseUrl;
    private final String apiKey;
    private final String organizationId;

    OpenAiResponsesClient(Builder builder) {
        HttpClientBuilder httpClientBuilder =
                getOrDefault(builder.httpClientBuilder, HttpClientBuilderLoader::loadHttpClientBuilder);
        HttpClient httpClient = httpClientBuilder.build();
        if (builder.logRequests || builder.logResponses) {
            this.httpClient = new LoggingHttpClient(httpClient, builder.logRequests, builder.logResponses);
        } else {
            this.httpClient = httpClient;
        }
        this.baseUrl = getOrDefault(builder.baseUrl, DEFAULT_BASE_URL);
        this.apiKey = builder.apiKey;
        this.organizationId = builder.organizationId;
    }

    static Builder builder() {
        return new Builder();
    }

    ChatResponse chat(ChatRequest chatRequest, OpenAiResponsesChatRequestParameters parameters) {
        try {
            Map<String, Object> payload = buildRequestPayload(chatRequest, parameters, false);
            HttpRequest request = buildHttpRequest(payload, false);
            SuccessfulHttpResponse rawHttpResponse = httpClient.execute(request);
            return parseChatResponse(rawHttpResponse);
        } catch (Exception e) {
            throw ExceptionMapper.DEFAULT.mapException(e);
        }
    }

    void streamingChat(ChatRequest chatRequest,
                       OpenAiResponsesChatRequestParameters parameters,
                       StreamingChatResponseHandler handler) {
        try {
            Map<String, Object> payload = buildRequestPayload(chatRequest, parameters, true);
            HttpRequest request = buildHttpRequest(payload, true);

            httpClient.execute(request, new DefaultServerSentEventParser(), new ResponsesApiEventListener(handler));

        } catch (Exception e) {
            withLoggingExceptions(() -> handler.onError(ExceptionMapper.DEFAULT.mapException(e)));
        }
    }

    private Map<String, Object> buildRequestPayload(ChatRequest chatRequest,
                                                    OpenAiResponsesChatRequestParameters parameters,
                                                    boolean stream) {
        List<Map<String, Object>> input = new ArrayList<>();
        for (ChatMessage message : chatRequest.messages()) {
            input.addAll(toResponsesMessages(message));
        }

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put(FIELD_MODEL, parameters.modelName());
        payload.put(FIELD_INPUT, input);
        payload.put(FIELD_STREAM, stream);
        payload.put(FIELD_STORE, parameters.store());

        if (parameters.temperature() != null) {
            payload.put(FIELD_TEMPERATURE, parameters.temperature());
        }

        if (parameters.topP() != null) {
            payload.put(FIELD_TOP_P, parameters.topP());
        }

        if (parameters.maxOutputTokens() != null) {
            payload.put(FIELD_MAX_OUTPUT_TOKENS, parameters.maxOutputTokens());
        }

        if (parameters.maxToolCalls() != null) {
            payload.put(FIELD_MAX_TOOL_CALLS, parameters.maxToolCalls());
        }

        if (parameters.parallelToolCalls() != null) {
            payload.put(FIELD_PARALLEL_TOOL_CALLS, parameters.parallelToolCalls());
        }

        if (parameters.previousResponseId() != null) {
            payload.put(FIELD_PREVIOUS_RESPONSE_ID, parameters.previousResponseId());
        }

        if (parameters.topLogprobs() != null) {
            payload.put(FIELD_TOP_LOGPROBS, parameters.topLogprobs());
        }

        if (parameters.truncation() != null && !parameters.truncation().isEmpty()) {
            payload.put(FIELD_TRUNCATION, parameters.truncation());
        }

        if (parameters.include() != null && !parameters.include().isEmpty()) {
            payload.put(FIELD_INCLUDE, parameters.include());
        }

        if (parameters.serviceTier() != null) {
            payload.put(FIELD_SERVICE_TIER, parameters.serviceTier());
        }

        if (parameters.safetyIdentifier() != null) {
            payload.put(FIELD_SAFETY_IDENTIFIER, parameters.safetyIdentifier());
        }

        if (parameters.promptCacheKey() != null) {
            payload.put(FIELD_PROMPT_CACHE_KEY, parameters.promptCacheKey());
        }

        if (parameters.promptCacheRetention() != null) {
            payload.put(FIELD_PROMPT_CACHE_RETENTION, parameters.promptCacheRetention());
        }

        if (parameters.reasoningEffort() != null || parameters.reasoningSummary() != null) {
            Map<String, Object> reasoning = new LinkedHashMap<>();
            if (parameters.reasoningEffort() != null) {
                reasoning.put(FIELD_EFFORT, parameters.reasoningEffort());
            }
            if (parameters.reasoningSummary() != null) {
                reasoning.put(FIELD_SUMMARY, parameters.reasoningSummary());
            }
            payload.put(FIELD_REASONING, reasoning);
        }

        if (stream && parameters.streamIncludeObfuscation() != null) {
            Map<String, Object> streamOptions = new LinkedHashMap<>();
            streamOptions.put(FIELD_INCLUDE_OBFUSCATION, parameters.streamIncludeObfuscation());
            payload.put(FIELD_STREAM_OPTIONS, streamOptions);
        }

        boolean strictTools = Boolean.TRUE.equals(parameters.strictTools());
        List<ToolSpecification> toolSpecifications = parameters.toolSpecifications();
        if (toolSpecifications != null && !toolSpecifications.isEmpty()) {
            List<Map<String, Object>> tools = new ArrayList<>();
            for (ToolSpecification toolSpec : toolSpecifications) {
                Map<String, Object> tool = new LinkedHashMap<>();
                tool.put(FIELD_TYPE, TYPE_FUNCTION);
                tool.put(FIELD_NAME, toolSpec.name());
                if (toolSpec.description() != null) {
                    tool.put(FIELD_DESCRIPTION, toolSpec.description());
                }

                Map<String, Object> functionParameters = null;
                if (toolSpec.parameters() != null) {
                    functionParameters = toMap(toolSpec.parameters(), strictTools);
                } else if (strictTools) {
                    functionParameters = new LinkedHashMap<>();
                    functionParameters.put(FIELD_TYPE, TYPE_OBJECT);
                    functionParameters.put(FIELD_PROPERTIES, Map.of());
                    functionParameters.put(FIELD_ADDITIONAL_PROPERTIES, false);
                }

                if (functionParameters != null) {
                    tool.put(FIELD_PARAMETERS, functionParameters);
                }

                if (strictTools) {
                    tool.put(FIELD_STRICT, true);
                }

                tools.add(tool);
            }
            payload.put(FIELD_TOOLS, tools);

            if (parameters.toolChoice() != null) {
                payload.put(FIELD_TOOL_CHOICE, toToolChoiceString(parameters.toolChoice()));
            }
        }

        boolean strictJsonSchema = Boolean.TRUE.equals(parameters.strictJsonSchema());
        Map<String, Object> textConfig = toResponseTextConfig(parameters.responseFormat(), strictJsonSchema);
        if (parameters.textVerbosity() != null) {
            if (textConfig == null) {
                textConfig = new LinkedHashMap<>();
            }
            textConfig.put(FIELD_TEXT_VERBOSITY, parameters.textVerbosity());
        }
        if (textConfig != null) {
            payload.put(FIELD_TEXT, textConfig);
        }

        return payload;
    }

    private HttpRequest buildHttpRequest(Map<String, Object> payload, boolean stream) throws Exception {
        String requestBody = OBJECT_MAPPER.writeValueAsString(payload);

        HttpRequest.Builder requestBuilder = HttpRequest.builder()
                .url(baseUrl + "/responses")
                .method(HttpMethod.POST)
                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", stream ? "text/event-stream" : "application/json");

        if (apiKey != null && !apiKey.isBlank()) {
            requestBuilder.addHeader("Authorization", "Bearer " + apiKey);
        }

        if (organizationId != null) {
            requestBuilder.addHeader(OPENAI_ORGANIZATION_HEADER, organizationId);
        }

        return requestBuilder.body(requestBody).build();
    }

    private static String extractText(JsonNode output) {
        if (!output.isArray()) {
            return null;
        }

        StringBuilder textBuilder = new StringBuilder();
        for (JsonNode item : output) {
            if (TYPE_MESSAGE.equals(item.path(FIELD_TYPE).asText())) {
                JsonNode content = item.path(FIELD_CONTENT);
                if (content.isArray()) {
                    for (JsonNode c : content) {
                        if (TYPE_OUTPUT_TEXT.equals(c.path(FIELD_TYPE).asText())) {
                            textBuilder.append(c.path(FIELD_TEXT).asText());
                        }
                    }
                }
            }
        }
        return textBuilder.isEmpty() ? null : textBuilder.toString();
    }

    private static String extractReasoningSummary(JsonNode output) {
        if (!output.isArray()) {
            return null;
        }

        StringBuilder summaryBuilder = new StringBuilder();
        for (JsonNode item : output) {
            if (TYPE_REASONING.equals(item.path(FIELD_TYPE).asText())) {
                JsonNode summaryArray = item.path(FIELD_SUMMARY);
                if (summaryArray.isArray()) {
                    for (JsonNode summaryItem : summaryArray) {
                        if (FIELD_SUMMARY_TEXT.equals(summaryItem.path(FIELD_TYPE).asText())) {
                            summaryBuilder.append(summaryItem.path(FIELD_TEXT).asText());
                        }
                    }
                }
            }
        }
        return summaryBuilder.isEmpty() ? null : summaryBuilder.toString();
    }

    private static String extractReasoningEncryptedContent(JsonNode output) {
        if (!output.isArray()) {
            return null;
        }

        for (JsonNode item : output) {
            if (TYPE_REASONING.equals(item.path(FIELD_TYPE).asText())) {
                JsonNode encryptedContent = item.path(FIELD_ENCRYPTED_CONTENT);
                if (!encryptedContent.isMissingNode() && !encryptedContent.isNull()) {
                    return encryptedContent.asText();
                }
            }
        }
        return null;
    }

    private static List<ToolExecutionRequest> extractToolExecutionRequests(JsonNode output) {
        if (!output.isArray()) {
            return List.of();
        }

        List<ToolExecutionRequest> toolExecutionRequests = new ArrayList<>();
        for (JsonNode item : output) {
            if (!TYPE_FUNCTION_CALL.equals(item.path(FIELD_TYPE).asText())) {
                continue;
            }

            String id = item.path(FIELD_CALL_ID).asText(null);
            if (id == null || id.isBlank()) {
                id = item.path(FIELD_ID).asText(null);
            }

            ToolExecutionRequest toolExecutionRequest = ToolExecutionRequest.builder()
                    .id(id)
                    .name(item.path(FIELD_NAME).asText())
                    .arguments(item.path(FIELD_ARGUMENTS).asText("{}"))
                    .build();
            toolExecutionRequests.add(toolExecutionRequest);
        }
        return toolExecutionRequests;
    }

    private static OpenAiTokenUsage parseTokenUsage(JsonNode usageNode) {
        if (usageNode == null || usageNode.isMissingNode() || usageNode.isNull()) {
            return null;
        }

        OpenAiTokenUsage.Builder usageBuilder = OpenAiTokenUsage.builder()
                .inputTokenCount(usageNode.path(FIELD_INPUT_TOKENS).asInt())
                .outputTokenCount(usageNode.path(FIELD_OUTPUT_TOKENS).asInt())
                .totalTokenCount(usageNode.path(FIELD_TOTAL_TOKENS).asInt());

        JsonNode inputDetailsNode = usageNode.path(FIELD_INPUT_TOKENS_DETAILS);
        if (!inputDetailsNode.isMissingNode()) {
            usageBuilder.inputTokensDetails(OpenAiTokenUsage.InputTokensDetails.builder()
                    .cachedTokens(inputDetailsNode.path(FIELD_CACHED_TOKENS).asInt())
                    .build());
        }

        JsonNode outputDetailsNode = usageNode.path(FIELD_OUTPUT_TOKENS_DETAILS);
        if (!outputDetailsNode.isMissingNode()) {
            usageBuilder.outputTokensDetails(OpenAiTokenUsage.OutputTokensDetails.builder()
                    .reasoningTokens(outputDetailsNode.path(FIELD_REASONING_TOKENS).asInt())
                    .build());
        }

        return usageBuilder.build();
    }

    private static FinishReason finishReasonFromStatus(String status, boolean hasToolCalls) {
        if (status == null || status.isBlank()) {
            return null;
        }
        return switch (status) {
            case "completed" -> hasToolCalls ? FinishReason.TOOL_EXECUTION : FinishReason.STOP;
            case "incomplete" -> FinishReason.LENGTH;
            case "failed" -> FinishReason.OTHER;
            default -> FinishReason.OTHER;
        };
    }

    private ChatResponse parseChatResponse(SuccessfulHttpResponse rawHttpResponse) throws Exception {
        JsonNode responseNode = OBJECT_MAPPER.readTree(rawHttpResponse.body());

        JsonNode outputNode = responseNode.path(FIELD_OUTPUT);
        String text = extractText(outputNode);
        String thinking = extractReasoningSummary(outputNode);
        String encryptedContent = extractReasoningEncryptedContent(outputNode);
        List<ToolExecutionRequest> toolExecutionRequests =
                extractToolExecutionRequests(outputNode);

        AiMessage.Builder aiMessageBuilder = AiMessage.builder()
                .text(text)
                .thinking(thinking)
                .toolExecutionRequests(toolExecutionRequests);
        if (encryptedContent != null) {
            aiMessageBuilder.attributes(Map.of(ENCRYPTED_REASONING_KEY, encryptedContent));
        }
        AiMessage aiMessage = aiMessageBuilder.build();


        OpenAiResponsesChatResponseMetadata.Builder metadataBuilder = OpenAiResponsesChatResponseMetadata.builder()
                .id(responseNode.path(FIELD_ID).asText(null))
                .modelName(responseNode.path(FIELD_MODEL).asText(null));

        OpenAiTokenUsage tokenUsage = parseTokenUsage(responseNode.path(FIELD_USAGE));
        if (tokenUsage != null) {
            metadataBuilder.tokenUsage(tokenUsage);
        }

        FinishReason finishReason =
                finishReasonFromStatus(responseNode.path(FIELD_STATUS).asText(null), !toolExecutionRequests.isEmpty());
        if (finishReason != null) {
            metadataBuilder.finishReason(finishReason);
        }

        if (responseNode.hasNonNull(FIELD_CREATED_AT)) {
            metadataBuilder.createdAt(responseNode.path(FIELD_CREATED_AT).asLong());
        }

        if (responseNode.hasNonNull(FIELD_COMPLETED_AT)) {
            metadataBuilder.completedAt(responseNode.path(FIELD_COMPLETED_AT).asLong());
        }

        if (responseNode.hasNonNull(FIELD_SERVICE_TIER)) {
            metadataBuilder.serviceTier(responseNode.path(FIELD_SERVICE_TIER).asText());
        }

        metadataBuilder.rawHttpResponse(rawHttpResponse);

        return ChatResponse.builder()
                .aiMessage(aiMessage)
                .metadata(metadataBuilder.build())
                .build();
    }

    private static List<Map<String, Object>> toResponsesMessages(ChatMessage msg) {
        if (msg instanceof SystemMessage systemMessage) {
            return List.of(createMessageEntry(ROLE_SYSTEM, List.of(createInputTextContent(systemMessage.text()))));
        } else if (msg instanceof UserMessage userMessage) {
            List<Map<String, Object>> contentEntries = new ArrayList<>();
            for (Content content : userMessage.contents()) {
                if (content instanceof TextContent textContent) {
                    contentEntries.add(createInputTextContent(textContent.text()));
                } else if (content instanceof ImageContent imageContent) {
                    contentEntries.add(createInputImageContent(imageContent.image(), imageContent.detailLevel()));
                } else if (content instanceof PdfFileContent pdfFileContent) {
                    contentEntries.add(createInputPdfContent(pdfFileContent));
                } else {
                    throw new UnsupportedFeatureException("Unsupported content type: "
                            + content.getClass().getName()
                            + ". Only TextContent, ImageContent, and PdfFileContent are supported.");
                }
            }
            return List.of(createMessageEntry(ROLE_USER, contentEntries));
        } else if (msg instanceof AiMessage aiMessage) {
            List<Map<String, Object>> items = new ArrayList<>();

            String encryptedContent = aiMessage.attribute(ENCRYPTED_REASONING_KEY, String.class);
            if (encryptedContent != null) {
                var reasoningItem = new LinkedHashMap<String, Object>();
                reasoningItem.put(FIELD_TYPE, TYPE_REASONING);
                reasoningItem.put(FIELD_ENCRYPTED_CONTENT, encryptedContent);
                List<Map<String, Object>> summaryItems = new ArrayList<>();
                if (aiMessage.thinking() != null && !aiMessage.thinking().isEmpty()) {
                    var summaryTextItem = new LinkedHashMap<String, Object>();
                    summaryTextItem.put(FIELD_TYPE, FIELD_SUMMARY_TEXT);
                    summaryTextItem.put(FIELD_TEXT, aiMessage.thinking());
                    summaryItems.add(summaryTextItem);
                }
                reasoningItem.put(FIELD_SUMMARY, summaryItems);
                items.add(reasoningItem);
            }

            var text = aiMessage.text();
            if (text != null && !text.isEmpty()) {
                items.add(createMessageEntry(ROLE_ASSISTANT, List.of(createOutputTextContent(text))));
            }

            if (aiMessage.hasToolExecutionRequests()) {
                for (ToolExecutionRequest toolRequest : aiMessage.toolExecutionRequests()) {
                    String callId = requireNonBlank(toolRequest.id(), "ToolExecutionRequest.id");
                    String name = requireNonBlank(toolRequest.name(), "ToolExecutionRequest.name");
                    String arguments = requireNonBlank(toolRequest.arguments(), "ToolExecutionRequest.arguments");
                    var functionCall = new LinkedHashMap<String, Object>();
                    functionCall.put(FIELD_TYPE, TYPE_FUNCTION_CALL);
                    functionCall.put(FIELD_CALL_ID, callId);
                    functionCall.put(FIELD_NAME, name);
                    functionCall.put(FIELD_ARGUMENTS, arguments);
                    items.add(functionCall);
                }
            }

            return items;
        } else if (msg instanceof ToolExecutionResultMessage toolExecutionResultMessage) {
            var outputEntry = new LinkedHashMap<String, Object>();
            outputEntry.put(FIELD_TYPE, TYPE_FUNCTION_CALL_OUTPUT);
            outputEntry.put(FIELD_CALL_ID, toolExecutionResultMessage.id());

            if (toolExecutionResultMessage.hasSingleText()) {
                outputEntry.put(FIELD_OUTPUT, toolExecutionResultMessage.text());
            } else {
                List<Map<String, Object>> outputContents = new ArrayList<>();
                for (Content content : toolExecutionResultMessage.contents()) {
                    if (content instanceof TextContent textContent) {
                        outputContents.add(createInputTextContent(textContent.text()));
                    } else if (content instanceof ImageContent imageContent) {
                        outputContents.add(createInputImageContent(imageContent.image(), imageContent.detailLevel()));
                    } else {
                        throw new UnsupportedFeatureException("Unsupported content type in tool result: "
                                + content.getClass().getName()
                                + ". Only TextContent and ImageContent are supported.");
                    }
                }
                outputEntry.put(FIELD_OUTPUT, outputContents);
            }

            return List.of(outputEntry);
        } else {
            throw new UnsupportedFeatureException(
                    "Unsupported message type: " + msg.getClass().getName()
                            + ". Only SystemMessage, UserMessage, AiMessage, and ToolExecutionResultMessage are supported.");
        }
    }

    private static Map<String, Object> createMessageEntry(String role, List<Map<String, Object>> contentEntries) {
        var entry = new LinkedHashMap<String, Object>();
        entry.put(FIELD_TYPE, TYPE_MESSAGE);
        entry.put(FIELD_ROLE, role);
        entry.put(FIELD_CONTENT, contentEntries);
        return entry;
    }

    private static Map<String, Object> createInputTextContent(String text) {
        var content = new LinkedHashMap<String, Object>();
        content.put(FIELD_TYPE, TYPE_INPUT_TEXT);
        content.put(FIELD_TEXT, text);
        return content;
    }

    private static Map<String, Object> createOutputTextContent(String text) {
        var content = new LinkedHashMap<String, Object>();
        content.put(FIELD_TYPE, TYPE_OUTPUT_TEXT);
        content.put(FIELD_TEXT, text);
        return content;
    }

    private static Map<String, Object> createInputImageContent(Image image, ImageContent.DetailLevel detailLevel) {
        var content = new LinkedHashMap<String, Object>();
        content.put(FIELD_TYPE, TYPE_INPUT_IMAGE);
        content.put(FIELD_IMAGE_URL, buildImageUrl(image));
        content.put(FIELD_DETAIL, toDetailString(detailLevel));
        return content;
    }

    private static Map<String, Object> createInputPdfContent(PdfFileContent pdfFileContent) {
        var content = new LinkedHashMap<String, Object>();
        content.put(FIELD_TYPE, TYPE_INPUT_FILE);
        if (pdfFileContent.pdfFile().url() != null) {
            content.put(FIELD_FILE_URL, pdfFileContent.pdfFile().url().toString());
        } else if (pdfFileContent.pdfFile().base64Data() != null) {
            content.put(FIELD_FILE_DATA, buildPdfFileData(pdfFileContent));
            content.put(FIELD_FILENAME, DEFAULT_PDF_FILENAME);
        } else {
            throw new IllegalArgumentException("PDF must have either url or base64Data");
        }
        return content;
    }

    private static String toDetailString(ImageContent.DetailLevel detailLevel) {
        return switch (detailLevel) {
            case LOW -> "low";
            case HIGH -> "high";
            case AUTO -> "auto";
            default -> throw new UnsupportedFeatureException(
                    "DetailLevel " + detailLevel + " is not supported by OpenAI Responses API. Supported values: LOW, HIGH, AUTO");
        };
    }

    private static String buildImageUrl(Image image) {
        if (image.url() != null) {
            return image.url().toString();
        } else if (image.base64Data() != null) {
            String mimeType = image.mimeType() != null ? image.mimeType() : DEFAULT_IMAGE_MIME_TYPE;
            return "data:" + mimeType + ";base64," + image.base64Data();
        } else {
            throw new IllegalArgumentException("Image must have either url or base64Data");
        }
    }

    private static String buildPdfFileData(PdfFileContent pdfFileContent) {
        if (pdfFileContent.pdfFile().base64Data() != null) {
            return "data:" + pdfFileContent.pdfFile().mimeType() + ";base64,"
                    + pdfFileContent.pdfFile().base64Data();
        } else {
            throw new IllegalArgumentException("PDF must have base64Data");
        }
    }

    private static String toToolChoiceString(ToolChoice toolChoice) {
        if (toolChoice == null) {
            return null;
        }
        return switch (toolChoice) {
            case AUTO -> "auto";
            case REQUIRED -> "required";
            case NONE -> "none";
        };
    }

    private static String requireNonBlank(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " must be provided");
        }
        return value;
    }

    private static Map<String, Object> toResponseTextConfig(ResponseFormat responseFormat, boolean strict) {
        if (responseFormat == null || responseFormat.type() == ResponseFormatType.TEXT) {
            return null;
        }

        var textConfig = new LinkedHashMap<String, Object>();
        JsonSchema jsonSchema = responseFormat.jsonSchema();

        if (jsonSchema == null) {
            var format = new LinkedHashMap<String, Object>();
            format.put(FIELD_TYPE, TYPE_JSON_OBJECT);
            textConfig.put(FIELD_FORMAT, format);
        } else {
            if (!(jsonSchema.rootElement() instanceof JsonObjectSchema
                    || jsonSchema.rootElement() instanceof JsonRawSchema)) {
                throw new IllegalArgumentException(
                        "For OpenAI, the root element of the JSON Schema must be either a JsonObjectSchema or a JsonRawSchema, but it was: "
                                + jsonSchema.rootElement().getClass());
            }

            var format = new LinkedHashMap<String, Object>();
            format.put(FIELD_TYPE, TYPE_JSON_SCHEMA);
            format.put(FIELD_STRICT, strict);
            if (jsonSchema.name() != null) {
                format.put(FIELD_NAME, jsonSchema.name());
            }
            format.put(FIELD_SCHEMA, toMap(jsonSchema.rootElement(), strict));

            textConfig.put(FIELD_FORMAT, format);
        }

        return textConfig;
    }

    static class Builder {

        private HttpClientBuilder httpClientBuilder;
        private String baseUrl;
        private String apiKey;
        private String organizationId;
        private boolean logRequests;
        private boolean logResponses;

        Builder httpClientBuilder(HttpClientBuilder httpClientBuilder) {
            this.httpClientBuilder = httpClientBuilder;
            return this;
        }

        Builder baseUrl(String baseUrl) {
            this.baseUrl = baseUrl;
            return this;
        }

        Builder apiKey(String apiKey) {
            this.apiKey = apiKey;
            return this;
        }

        Builder organizationId(String organizationId) {
            this.organizationId = organizationId;
            return this;
        }

        Builder logRequests(Boolean logRequests) {
            if (logRequests != null) {
                this.logRequests = logRequests;
            }
            return this;
        }

        Builder logResponses(Boolean logResponses) {
            if (logResponses != null) {
                this.logResponses = logResponses;
            }
            return this;
        }

        OpenAiResponsesClient build() {
            return new OpenAiResponsesClient(this);
        }
    }

    private static class ResponsesApiEventListener implements ServerSentEventListener {

        private final StreamingChatResponseHandler handler;
        private volatile StreamingHandle streamingHandle;
        private final Map<String, ToolExecutionRequest.Builder> toolCallBuilders = new LinkedHashMap<>();
        private final Map<String, Integer> toolCallIndices = new LinkedHashMap<>();
        private final List<ToolExecutionRequest> completedToolCalls = new ArrayList<>();
        private final Set<String> completedToolCallItemIds = new HashSet<>();
        private final List<ServerSentEvent> rawServerSentEvents = new ArrayList<>();
        private SuccessfulHttpResponse rawHttpResponse;

        ResponsesApiEventListener(StreamingChatResponseHandler handler) {
            this.handler = handler;
        }

        private boolean isCancelled() {
            return streamingHandle != null && streamingHandle.isCancelled();
        }

        private void assignIndexIfAbsent(String itemId, int index) {
            toolCallIndices.putIfAbsent(itemId, index);
        }

        @Override
        public void onOpen(SuccessfulHttpResponse response) {
            this.rawHttpResponse = response;
        }

        @Override
        public void onEvent(ServerSentEvent event) {
            onEvent(event, new ServerSentEventContext(new CancellationUnsupportedHandle()));
        }

        @Override
        public void onEvent(ServerSentEvent event, ServerSentEventContext context) {
            if (streamingHandle == null) {
                streamingHandle = toStreamingHandle(context.parsingHandle());
            }

            if (isCancelled()) {
                return;
            }
            rawServerSentEvents.add(event);
            var data = event.data();

            if (data == null || data.isEmpty()) {
                return;
            }

            if (STREAM_DONE_MARKER.equals(data)) {
                return;
            }

            handleDelta(data);
        }

        @Override
        public void onError(Throwable error) {
            withLoggingExceptions(() -> handler.onError(ExceptionMapper.DEFAULT.mapException(error)));
        }

        private void handleDelta(String data) {
            if (!data.trim().startsWith("{") && !data.trim().startsWith("[")) {
                return;
            }

            try {
                var node = OBJECT_MAPPER.readTree(data);
                var type = node.has(FIELD_TYPE) ? node.get(FIELD_TYPE).asText() : "";

                if (EVENT_OUTPUT_TEXT_DELTA.equals(type)) {
                    var text = node.path(FIELD_DELTA).asText();
                    if (!text.isEmpty()) {
                        InternalStreamingChatResponseHandlerUtils.onPartialResponse(handler, text, streamingHandle);
                    }
                } else if (EVENT_REASONING_TEXT_DELTA.equals(type) || EVENT_REASONING_SUMMARY_TEXT_DELTA.equals(type)) {
                    var thinking = node.path(FIELD_DELTA).asText();
                    if (!thinking.isEmpty()) {
                        InternalStreamingChatResponseHandlerUtils.onPartialThinking(handler, thinking, streamingHandle);
                    }
                } else if (EVENT_OUTPUT_ITEM_ADDED.equals(type)) {
                    var item = node.path(FIELD_ITEM);
                    if (TYPE_FUNCTION_CALL.equals(item.path(FIELD_TYPE).asText())) {
                        var itemId = item.path(FIELD_ID).asText();
                        int outputIndex = node.path(FIELD_OUTPUT_INDEX).asInt(0);
                        toolCallBuilders.put(
                                itemId,
                                ToolExecutionRequest.builder()
                                        .id(item.path(FIELD_CALL_ID).asText())
                                        .name(item.path(FIELD_NAME).asText())
                                        .arguments(""));
                        assignIndexIfAbsent(itemId, outputIndex);
                    }
                } else if (EVENT_FUNCTION_CALL_ARGUMENTS_DELTA.equals(type)) {
                    var itemId = node.path(FIELD_ITEM_ID).asText();
                    var builder = toolCallBuilders.get(itemId);
                    if (builder != null) {
                        var currentArgs = builder.build().arguments();
                        String delta = node.path(FIELD_DELTA).asText();
                        builder.arguments(currentArgs + delta);
                        Integer index = toolCallIndices.get(itemId);
                        if (index != null && !delta.isEmpty()) {
                            PartialToolCall partialToolCall = PartialToolCall.builder()
                                    .index(index)
                                    .id(builder.build().id())
                                    .name(builder.build().name())
                                    .partialArguments(delta)
                                    .build();
                            InternalStreamingChatResponseHandlerUtils.onPartialToolCall(
                                    handler, partialToolCall, streamingHandle);
                        }
                    }
                } else if (EVENT_FUNCTION_CALL_ARGUMENTS_DONE.equals(type)) {
                    var itemId = node.path(FIELD_ITEM_ID).asText();
                    var builder = toolCallBuilders.get(itemId);
                    if (builder != null) {
                        builder.arguments(node.path(FIELD_ARGUMENTS).asText());
                        completeToolCall(itemId, builder);
                    }
                } else if (EVENT_OUTPUT_ITEM_DONE.equals(type)) {
                    handleOutputItemDone(node);
                } else if (EVENT_RESPONSE_COMPLETED.equals(type) || EVENT_RESPONSE_INCOMPLETE.equals(type)) {
                    handleResponseCompleted(node);
                } else if (EVENT_RESPONSE_FAILED.equals(type) || EVENT_RESPONSE_ERROR.equals(type)) {
                    handleResponseFailure(node);
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        private void handleOutputItemDone(JsonNode node) {
            var item = node.path(FIELD_ITEM);
            if (TYPE_FUNCTION_CALL.equals(item.path(FIELD_TYPE).asText())) {
                var itemId = item.path(FIELD_ID).asText();
                int outputIndex = node.path(FIELD_OUTPUT_INDEX).asInt(0);
                var builder = toolCallBuilders.computeIfAbsent(itemId, ignored -> ToolExecutionRequest.builder());
                assignIndexIfAbsent(itemId, outputIndex);

                var callIdNode = item.get(FIELD_CALL_ID);
                if (callIdNode != null && !callIdNode.isNull()) {
                    builder.id(callIdNode.asText());
                }
                var nameNode = item.get(FIELD_NAME);
                if (nameNode != null && !nameNode.isNull()) {
                    builder.name(nameNode.asText());
                }
                var argumentsNode = item.get(FIELD_ARGUMENTS);
                if (argumentsNode != null && !argumentsNode.isNull()) {
                    builder.arguments(argumentsNode.asText());
                }

                completeToolCall(itemId, builder);
            }
        }

        private void handleResponseCompleted(JsonNode node) {
            var responseNode = node.path(FIELD_RESPONSE);

            JsonNode outputNode = responseNode.path(FIELD_OUTPUT);
            String text = extractText(outputNode);
            String thinking = extractReasoningSummary(outputNode);
            String encryptedContent = extractReasoningEncryptedContent(outputNode);

            AiMessage.Builder aiMessageBuilder = AiMessage.builder()
                    .text(text)
                    .thinking(thinking)
                    .toolExecutionRequests(completedToolCalls);
            if (encryptedContent != null) {
                aiMessageBuilder.attributes(Map.of(ENCRYPTED_REASONING_KEY, encryptedContent));
            }
            var aiMessage = aiMessageBuilder.build();

            OpenAiResponsesChatResponseMetadata.Builder metadataBuilder = OpenAiResponsesChatResponseMetadata.builder()
                    .id(responseNode.path(FIELD_ID).asText(null))
                    .modelName(responseNode.path(FIELD_MODEL).asText(null));

            OpenAiTokenUsage tokenUsage = parseTokenUsage(responseNode.path(FIELD_USAGE));
            if (tokenUsage != null) {
                metadataBuilder.tokenUsage(tokenUsage);
            }

            FinishReason finishReason = finishReasonFromStatus(
                    responseNode.path(FIELD_STATUS).asText(null), !completedToolCalls.isEmpty());
            if (finishReason != null) {
                metadataBuilder.finishReason(finishReason);
            }

            if (responseNode.hasNonNull(FIELD_CREATED_AT)) {
                metadataBuilder.createdAt(responseNode.path(FIELD_CREATED_AT).asLong());
            }
            if (responseNode.hasNonNull(FIELD_COMPLETED_AT)) {
                metadataBuilder.completedAt(responseNode.path(FIELD_COMPLETED_AT).asLong());
            }
            if (responseNode.hasNonNull(FIELD_SERVICE_TIER)) {
                metadataBuilder.serviceTier(responseNode.path(FIELD_SERVICE_TIER).asText());
            }
            if (rawHttpResponse != null) {
                metadataBuilder.rawHttpResponse(rawHttpResponse);
            }
            if (!rawServerSentEvents.isEmpty()) {
                metadataBuilder.rawServerSentEvents(new ArrayList<>(rawServerSentEvents));
            }

            var responseBuilder = ChatResponse.builder()
                    .aiMessage(aiMessage)
                    .metadata(metadataBuilder.build());

            if (!isCancelled()) {
                try {
                    handler.onCompleteResponse(responseBuilder.build());
                } catch (Exception e) {
                    withLoggingExceptions(() -> handler.onError(e));
                }
            }
        }

        private void handleResponseFailure(JsonNode node) {
            JsonNode errorNode = node.path(FIELD_ERROR);
            if (errorNode.isMissingNode()) {
                errorNode = node.path(FIELD_RESPONSE).path(FIELD_ERROR);
            }
            String message = extractErrorMessage(errorNode);
            withLoggingExceptions(() -> handler.onError(new RuntimeException(message)));
        }

        private String extractErrorMessage(JsonNode errorNode) {
            if (errorNode == null || errorNode.isMissingNode() || errorNode.isNull()) {
                return "Response failed";
            }
            String message = errorNode.path(FIELD_MESSAGE).asText(null);
            if (message == null || message.isBlank()) {
                message = errorNode.toString();
            }
            return "Response failed: " + message;
        }

        private void completeToolCall(String itemId, ToolExecutionRequest.Builder builder) {
            if (builder == null || completedToolCallItemIds.contains(itemId)) {
                return;
            }
            ToolExecutionRequest toolExecutionRequest = builder.build();
            completedToolCalls.add(toolExecutionRequest);
            completedToolCallItemIds.add(itemId);
            toolCallBuilders.remove(itemId);
            Integer index = toolCallIndices.remove(itemId);
            int safeIndex = index != null ? index : completedToolCalls.size() - 1;
            if (!isCancelled()) {
                InternalStreamingChatResponseHandlerUtils.onCompleteToolCall(
                        handler, new CompleteToolCall(safeIndex, toolExecutionRequest));
            }
        }
    }
}
